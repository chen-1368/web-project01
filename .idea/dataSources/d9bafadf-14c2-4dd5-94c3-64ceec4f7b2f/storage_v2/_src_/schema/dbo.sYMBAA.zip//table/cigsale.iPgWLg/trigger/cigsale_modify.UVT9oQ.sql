create definer = root@localhost trigger cigsale_modify
    after insert
    on cigsale
    for each row
begin
update cigsale set saleamount=salecount*saleprice
where cigbrand=new.cigbrand;
end;

