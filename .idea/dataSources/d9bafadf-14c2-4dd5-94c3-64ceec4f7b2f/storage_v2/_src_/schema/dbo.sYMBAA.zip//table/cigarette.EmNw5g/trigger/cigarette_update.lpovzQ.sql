create definer = root@localhost trigger cigarette_update
    after update
    on cigarette
    for each row
begin
update cigarette set cigamount=cigcount*cigprice
where cigbrand=new.cigbrand;
end;

