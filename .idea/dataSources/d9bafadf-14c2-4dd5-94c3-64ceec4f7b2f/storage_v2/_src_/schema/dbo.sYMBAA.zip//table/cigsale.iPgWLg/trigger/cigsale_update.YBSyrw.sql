create definer = root@localhost trigger cigsale_update
    after update
    on cigsale
    for each row
begin
update cigsale set saleamount=salecount*saleprice
where cigbrand=new.cigbrand;
end;

